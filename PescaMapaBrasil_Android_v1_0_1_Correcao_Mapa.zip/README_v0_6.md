# PescaMapa Brasil Android v0.6

## Incluído
- Marcadores demonstrativos no mapa MapLibre.
- Seleção de marcador para abrir ficha do local.
- Ficha com ambiente, tipo de pesca, espécies, iscas, segurança e observações.
- Arquivo `app/src/main/assets/pontos_mapa_prototipo.json`.
- Modelo Kotlin `FishingSpotMapItem.kt`.

## Aviso importante sobre coordenadas
As coordenadas desta versão são aproximadas e servem somente para demonstrar a interface. Não são precisas o suficiente para navegação nem para orientar o pescador até uma estrutura específica. Antes de publicação, validar os pontos em mapa confiável e/ou em campo, verificar acesso e regras locais e substituir as coordenadas.

## Estado do desenvolvimento
Este é código-fonte de protótipo. Ainda precisa de compilação e teste em Android Studio. O ciclo de vida do MapView, integração à navegação e compatibilidade com a versão exata do MapLibre deverão ser validados em build.

## Próximas etapas
1. Validar e corrigir coordenadas.
2. Ligar ciclo de vida do MapView à Activity.
3. Integrar GPS com consentimento e permissão.
4. Carregar fichas diretamente do JSON, em vez da lista de demonstração Kotlin.
5. Acrescentar filtros por ambiente e espécie.
