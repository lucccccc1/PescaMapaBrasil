# PescaMapa Brasil Android v0.3

## Nova etapa: Base de pesca

Foram adicionados dois bancos locais em `app/src/main/assets/`:

- `rio_das_ostras_pontos.json`
- `peixes_rio_das_ostras_v1.json`
- `regras_seguranca_v1.json`

A base de peixes usa ocorrência regional como referência, sem prometer captura.

## Decisão de arquitetura

O aplicativo deve separar:
1. Local
2. Ambiente
3. Espécies
4. Iscas
5. Técnicas
6. Condições
7. Segurança
8. Relatos dos usuários

A próxima camada é transformar isso em um motor de recomendação. Ele deverá bloquear recomendações inseguras/restritas antes de calcular produtividade.

## Próxima integração

- mapa real
- GPS
- marcador de pontos
- ficha do ponto
- condições de maré/vento/ondas
- recomendação explicável: "por que este ponto está sendo sugerido?"
