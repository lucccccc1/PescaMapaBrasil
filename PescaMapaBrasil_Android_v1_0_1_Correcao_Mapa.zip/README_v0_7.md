# PescaMapa Brasil Android - versão 0.7

## O que foi acrescentado
- Solicitação de permissão de localização somente quando o usuário toca em "Usar minha localização".
- Aceita localização aproximada ou precisa, conforme a escolha feita no Android.
- Consulta da última posição conhecida e atualização enquanto a tela do mapa está aberta.
- Marcador da posição do aparelho no mapa.
- Lista dos pontos cadastrados ordenada pela distância em linha reta.
- Botão para centralizar o mapa na posição do usuário.
- Cálculo de distância por Haversine.

## Privacidade
- A posição é lida localmente pelo aparelho.
- Esta versão não envia a localização para servidor nem mantém histórico.
- A permissão pode ser revogada a qualquer momento nas configurações do Android.
- Sem permissão, o mapa e os pontos demonstrativos continuam disponíveis.

## Limitações importantes
- As coordenadas dos pontos de Rio das Ostras ainda são aproximadas e precisam de validação presencial ou por fonte confiável.
- A distância exibida é em linha reta, não é distância por estrada/trilha e não é orientação de navegação.
- O mapa usa o estilo de demonstração público do MapLibre. Para produção, configurar provedor/estilo e respeitar os termos e limites de uso.
- O marcador azul/vermelho do usuário usa o marcador padrão do MapLibre nesta versão.
- A integração do ciclo de vida do MapView ainda deve ser validada em aparelho e ajustada caso a versão específica do SDK exija callbacks adicionais.
- Este pacote é código-fonte Android, não é APK compilado.

## Como testar
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute em um aparelho Android com internet e localização ativada.
4. Abra a aba Mapa e toque em "Usar minha localização".
5. Escolha localização aproximada ou precisa no diálogo do Android.
6. Confira se o marcador e a lista de distâncias aparecem.

## Próximas etapas sugeridas
1. Corrigir e testar o ciclo de vida do MapView em aparelho real.
2. Validar coordenadas e regras de acesso dos pontos de pesca.
3. Implementar botão de navegação externa com aviso de que o ponto é aproximado.
4. Integrar maré, vento e ondas usando fontes de dados adequadas.
