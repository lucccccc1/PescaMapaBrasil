# PescaMapa Brasil - Android v0.2

## O que mudou nesta versão

- Adicionado o banco inicial de pontos de pesca de Rio das Ostras.
- Arquivo de dados incluído em:
  `app/src/main/assets/rio_das_ostras_pontos.json`
- A base contém pontos, ambiente, tipo de pesca, segurança, observações e fonte.
- O próximo passo de programação é criar o repositório local que lê esse JSON e alimentar a tela do mapa/lista com os pontos.

## Importante

Esta versão ainda é um protótipo. O mapa real, GPS, maré, previsão do tempo, ondas e sincronização online serão integrados nas próximas etapas.

## Estratégia de baixo custo

A primeira integração de mapa pode ser feita com uma solução baseada em OpenStreetMap/MapLibre, evitando depender imediatamente de uma plataforma de mapas paga. Depois podemos avaliar outras opções.
