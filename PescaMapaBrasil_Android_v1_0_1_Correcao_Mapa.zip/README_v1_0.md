# PescaMapa Brasil Android - versão 1.0.0

## Novidade principal: calendário de defeso integrado
- Nova tela Calendário de Defeso acessível pelo menu inferior.
- Atalho na tela inicial.
- Resumo e acesso ao calendário dentro da ficha do ponto de pesca.
- Catálogo inicial de regras marinhas consultadas para o RJ.
- Períodos anuais que atravessam dezembro/janeiro são avaliados pelo núcleo `DefesoCalendar`.
- Caranguejo-uçá separado corretamente por sexo: machos de 01/out a 30/nov; fêmeas de 01/out a 31/dez.

## Cautelas legais
- O selo de período indica apenas que a data está dentro do intervalo cadastrado. Não confirma sozinho a incidência legal.
- É necessário conferir espécie, área geográfica, atividade, equipamento e eventuais exceções na norma vigente.
- Fora do período de uma regra não significa pesca liberada.
- Defeso de coleta/extração não deve ser confundido com proibição geral de pesca com vara e anzol.
- Regras de áreas protegidas e acesso permanecem separadas do calendário de defeso.
- Revisar as normas oficiais antes de publicar o aplicativo e antes de cada temporada.

## Fontes de referência
- IBAMA, Defesos marinhos: https://www.gov.br/ibama/pt-br/assuntos/biodiversidade/biodiversidade-aquatica/periodos-de-defeso/defesos-marinhos
- IBAMA, Defesos continentais: https://www.gov.br/ibama/pt-br/assuntos/biodiversidade/biodiversidade-aquatica/periodos-de-defeso/defesos-continentais
- FIPERJ, legislação: https://www.rj.gov.br/fiperj/legislacao
- FIPERJ, tabela estadual de defeso consultada (01/08/2025): https://www.rj.gov.br/fiperj/sites/default/files/arquivos-paginas/TABELA%20DE%20DEFESO_20250801_123614_0000_0.pdf

## Estado técnico
- `versionCode=10`, `versionName=1.0.0`.
- Este pacote contém código-fonte Android, não APK instalável.
- Não foi possível executar compilação Gradle nem teste em dispositivo nesta etapa. A compilação e validação no Android Studio continuam obrigatórias antes de distribuição.
- A tela apresenta um catálogo Kotlin estático correspondente às regras principais; o JSON continua incluído como base estruturada para integração dinâmica posterior.


## Revisão corretiva 1.0.1
- Corrigido o gerenciamento do ciclo de vida do MapView: start/resume/pause/stop/destroy agora acompanham os eventos do Lifecycle e a saída da tela.
- Removidas chamadas prematuras a onStart/onResume durante a criação da view.
- Adicionado opt-in explícito à API Material3 da barra superior.
- versionCode 11 / versionName 1.0.1.
- Esta entrega continua sendo código-fonte. Ainda não foi compilada nem testada em dispositivo Android; o ambiente de auditoria não possui Gradle, Gradle Wrapper ou Android SDK instalados.
