# PescaMapa Brasil Android v0.5

- Adicionada dependência MapLibre Android 11.8.0.
- Adicionada permissão de internet.
- Criada a tela Compose `MapLibreMapScreen()` com enquadramento regional aproximado de Rio das Ostras.
- Preservados os bancos de pontos, peixes, regras de segurança e motor inicial.

## Limitações
Esta é uma etapa de integração, ainda não um APK pronto para publicação.
A tela de mapa precisa ser conectada à navegação e ao ciclo de vida da Activity.
GPS e marcadores individuais ainda não estão ativados.
Nenhuma coordenada de ponto foi inventada: os marcadores entram após validação.
O estilo de demonstração é temporário; para produção, selecionar provedor de mapas e respeitar atribuição, cache e limites de uso.

## Próximas etapas
1. Integrar o mapa à navegação.
2. Validar coordenadas de cada ponto.
3. Adicionar marcadores e ficha do ponto.
4. Integrar GPS com permissão do usuário.
5. Conectar maré, vento e ondas.
