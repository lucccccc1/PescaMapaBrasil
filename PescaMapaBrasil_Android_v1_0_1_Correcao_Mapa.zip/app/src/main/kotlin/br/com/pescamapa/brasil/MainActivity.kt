package br.com.pescamapa.brasil

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Blue = Color(0xFF07539B)
private val LightBlue = Color(0xFFE8F5FC)
private val Yellow = Color(0xFFF3B719)

data class FishingSpot(
    val name: String,
    val city: String,
    val type: String,
    val rating: Double,
    val fish: List<String>
)

val sampleSpot = FishingSpot(
    "Costa Azul",
    "Rio das Ostras - RJ",
    "Praia + costão",
    4.5,
    listOf("Robalo", "Corvina", "Xerelete", "Pampo", "Betara")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { PescaMapaApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PescaMapaApp() {
    var screen by remember { mutableStateOf("home") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Blue,
            secondary = Yellow
        )
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = { Text("🎣 PescaMapa Brasil", fontWeight = FontWeight.Bold) },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = Blue,
                        titleContentColor = Color.White
                    )
                )
            },
            bottomBar = {
                NavigationBar {
                    NavItem("Início", Icons.Default.Home, screen == "home") { screen = "home" }
                    NavItem("Mapa", Icons.Default.Place, screen == "map") { screen = "map" }
                    NavItem("Peixes", Icons.Default.Pets, screen == "fish") { screen = "fish" }
                    NavItem("Comunidade", Icons.Default.Groups, screen == "community") { screen = "community" }
                    NavItem("Defeso", Icons.Default.DateRange, screen == "defeso") { screen = "defeso" }
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding)) {
                when (screen) {
                    "map" -> MapScreen { screen = "spot" }
                    "spot" -> SpotScreen(onRegister = { screen = "register" }, onDefeso = { screen = "defeso" })
                    "fish" -> FishScreen { screen = "map" }
                    "register" -> RegisterScreen()
                    "community" -> CommunityScreen()
                    "defeso" -> DefesoScreen()
                    else -> HomeScreen(
                        onMap = { screen = "map" },
                        onFish = { screen = "fish" },
                        onRegister = { screen = "register" },
                        onSafety = { screen = "spot" },
                        onDefeso = { screen = "defeso" }
                    )
                }
            }
        }
    }
}

@Composable
fun NavItem(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean, onClick: () -> Unit) {
    NavigationBarItem(
        selected = selected,
        onClick = onClick,
        icon = { Icon(icon, contentDescription = label) },
        label = { Text(label) }
    )
}

@Composable
fun HomeScreen(onMap: () -> Unit, onFish: () -> Unit, onRegister: () -> Unit, onSafety: () -> Unit, onDefeso: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = Blue),
                shape = RoundedCornerShape(20.dp)
            ) {
                Column(Modifier.padding(22.dp)) {
                    Text("Encontre o ponto.", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text("Descubra o peixe. Pesque com segurança.", color = Color.White, modifier = Modifier.padding(top = 6.dp))
                    Button(onClick = onMap, modifier = Modifier.padding(top = 18.dp), colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Blue)) {
                        Text("📍 Usar minha localização")
                    }
                }
            }
        }
        item {
            OutlinedTextField(
                value = "",
                onValueChange = {},
                modifier = Modifier.fillMaxWidth(),
                placeholder = { Text("🔎 Pesquisar praia, rio, lagoa ou cidade") },
                singleLine = true
            )
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("🗺️", "Mapa de Pesca", Modifier.weight(1f), onMap)
                FeatureCard("🐟", "Peixes", Modifier.weight(1f), onFish)
            }
        }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                FeatureCard("🎣", "Registrar", Modifier.weight(1f), onRegister)
                FeatureCard("🛡️", "Segurança", Modifier.weight(1f), onSafety)
            }
        }
        item {
            OutlinedButton(onClick = onDefeso, modifier = Modifier.fillMaxWidth()) { Text("📅 Calendário de Defeso") }
        }
        item {
            Text("🔥 Pescarias recentes", fontSize = 21.sp, fontWeight = FontWeight.Bold)
            InfoCard("Robalo • 42 cm", "Costa Azul • camarão artificial • 06:35")
        }
    }
}

@Composable
fun FeatureCard(icon: String, title: String, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable { onClick() }, colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(icon, fontSize = 30.sp)
            Text(title, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun MapScreen(onSpot: () -> Unit) {
    MapLibreMapScreen()
}

@Composable
fun SpotScreen(onRegister: () -> Unit, onDefeso: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("📍 Costa Azul", fontSize = 26.sp, fontWeight = FontWeight.Bold)
            Text("Rio das Ostras - RJ")
        }
        item { InfoCard("⭐ 4,5/5", "🏖️ Praia + costão") }
        item { InfoCard("🐟 Espécies", sampleSpot.fish.joinToString(", ")) }
        item { InfoCard("🎣 Iscas", "Camarão, sardinha e artificiais") }
        item { InfoCard("⏰ Horários", "Amanhecer e final da tarde") }
        item { InfoCard("🛡️ Segurança", "🟢 Boa. Atenção no costão em maré alta.") }
        item { DefesoSpotSummary(onOpenCalendar = onDefeso) }
        item {
            Button(onClick = onRegister, modifier = Modifier.fillMaxWidth()) {
                Text("🎣 Registrar minha pescaria")
            }
        }
    }
}

@Composable
fun FishScreen(onLocations: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("🐟 Banco de Peixes", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item { Text("ROBALО", fontSize = 30.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("Onde encontrar", "Praias, costões, estuários, manguezais e lagoas.") }
        item { InfoCard("Iscas", "🦐 Camarão • 🎣 artificiais • 🐟 pequenos peixes") }
        item { InfoCard("Técnicas", "Fundo, arremesso e artificial.") }
        item { Button(onClick = onLocations, modifier = Modifier.fillMaxWidth()) { Text("📍 Ver locais com registros") } }
    }
}

@Composable
fun RegisterScreen() {
    var saved by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("🎣 Registrar Pescaria", fontSize = 25.sp, fontWeight = FontWeight.Bold)
        OutlinedTextField("Robalo", {}, label = { Text("Espécie") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField("Camarão artificial", {}, label = { Text("Isca") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField("Costa Azul - RJ", {}, label = { Text("Local") }, modifier = Modifier.fillMaxWidth())
        OutlinedTextField("42", {}, label = { Text("Tamanho (cm)") }, modifier = Modifier.fillMaxWidth())
        Button(onClick = { saved = true }, modifier = Modifier.fillMaxWidth()) { Text("💾 Salvar registro") }
        if (saved) Text("✅ Pescaria registrada no protótipo!", color = Color(0xFF16833B), fontWeight = FontWeight.Bold)
    }
}

@Composable
fun CommunityScreen() {
    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("👥 Comunidade", fontSize = 25.sp, fontWeight = FontWeight.Bold) }
        item { InfoCard("Carlos Silva", "Robalo de 48 cm na Costa Azul! Camarão artificial às 06h. 👍 128  💬 32") }
        item { InfoCard("Marcos Pesca", "Hoje o mar estava bem mexido, mas saiu peixe.") }
    }
}

@Composable
fun InfoCard(title: String, text: String) {
    Card(colors = CardDefaults.cardColors(containerColor = Color.White)) {
        Column(Modifier.padding(16.dp)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Text(text, modifier = Modifier.padding(top = 5.dp), color = Color(0xFF52677A))
        }
    }
}
