package br.com.pescamapa.brasil

import java.time.LocalDate
import java.time.MonthDay

/**
 * Núcleo de avaliação do calendário de defeso.
 *
 * A interface deve cruzar espécie, atividade, equipamento e área antes de
 * mostrar uma proibição. Este mecanismo não substitui a validação jurídica
 * da norma nem determina sozinho que a pesca está liberada.
 */
data class DefesoRule(
    val id: String,
    val species: List<String>,
    val startMonthDay: MonthDay,
    val endMonthDay: MonthDay,
    val geographicScope: String,
    val activityScope: String,
    val gearScope: String,
    val exceptions: List<String>,
    val legalReference: String,
    val sourceUrls: List<String>,
    val confidence: String
)

enum class DefesoStatus {
    ACTIVE,
    UPCOMING,
    NOT_APPLICABLE,
    NEEDS_VERIFICATION
}

data class DefesoEvaluation(
    val status: DefesoStatus,
    val title: String,
    val explanation: String,
    val rule: DefesoRule? = null
)

object DefesoCalendar {
    /**
     * Avalia apenas o intervalo anual. A compatibilidade de localidade,
     * espécie, atividade e equipamento deve ser confirmada pelo chamador.
     */
    fun isDateInsidePeriod(date: LocalDate, start: MonthDay, end: MonthDay): Boolean {
        val current = MonthDay.from(date)
        return if (start <= end) {
            current >= start && current <= end
        } else {
            // Períodos que atravessam a virada do ano, por exemplo nov-fev.
            current >= start || current <= end
        }
    }

    fun evaluate(
        rule: DefesoRule,
        date: LocalDate,
        speciesConfirmed: Boolean,
        geographicScopeConfirmed: Boolean,
        activityAndGearConfirmed: Boolean
    ): DefesoEvaluation {
        if (!speciesConfirmed || !geographicScopeConfirmed || !activityAndGearConfirmed) {
            return DefesoEvaluation(
                DefesoStatus.NEEDS_VERIFICATION,
                "Verificação necessária",
                "Confirme espécie, área, atividade e equipamento na norma oficial antes de concluir.",
                rule
            )
        }

        return if (isDateInsidePeriod(date, rule.startMonthDay, rule.endMonthDay)) {
            DefesoEvaluation(
                DefesoStatus.ACTIVE,
                "Defeso vigente para esta regra",
                "A regra consultada está dentro do período informado. Leia as exceções e a norma completa.",
                rule
            )
        } else {
            DefesoEvaluation(
                DefesoStatus.NOT_APPLICABLE,
                "Fora do período desta regra",
                "Isso não significa liberação geral: outras regras, áreas protegidas ou restrições locais podem se aplicar.",
                rule
            )
        }
    }
}
