package br.com.pescamapa.brasil

data class FishingSpotMapItem(
    val id: String,
    val name: String,
    val latitude: Double?,
    val longitude: Double?,
    val environment: String,
    val fishing: String,
    val species: String,
    val bait: String,
    val safety: String,
    val status: String,
    val coordinateStatus: String,
    val accessStatus: String,
    val source: String
)

object RioDasOstrasPrototypeSpots {
    // v0.8: nenhum ponto recebe coordenada inventada. Sem coordenada validada,
    // o local aparece no catálogo, mas não recebe marcador nem cálculo de distância.
    val all = listOf(
        FishingSpotMapItem(
            id = "ro-001", name = "Píer do Emissário de Costazul", latitude = null, longitude = null,
            environment = "Píer / mar aberto", fishing = "Pesca de caniço indicada em material oficial de turismo",
            species = "Espécies costeiras; confirmar relatos recentes.",
            bait = "Definir conforme espécie-alvo, maré e condições do dia.",
            safety = "Observe placas, condições do mar, vento, iluminação e eventuais interdições.",
            status = "A Prefeitura identifica o píer como ponto para pesca de caniço. Confirme as regras e o acesso no dia.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Referência turística oficial; verificar sinalização e funcionamento no local.",
            source = "Prefeitura de Rio das Ostras: Pontos Turísticos; Jornal Oficial, edição 1896/2026."
        ),
        FishingSpotMapItem(
            id = "ro-002", name = "Praia de Costazul", latitude = null, longitude = null,
            environment = "Praia oceânica", fishing = "Pesca de praia somente em trecho e horário compatíveis com as regras locais",
            species = "Espécies costeiras variam com época e condições.",
            bait = "Iscas naturais adequadas à espécie-alvo; consultar relatos recentes.",
            safety = "Mantenha distância de banhistas, surfistas e áreas sinalizadas; observe correntes e ondas.",
            status = "Praia identificada em fontes oficiais como frequentada por praticantes de pesca de caniço; isso não libera todos os trechos/horários.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Praia pública; regras específicas de pesca por trecho/horário precisam ser confirmadas.",
            source = "Portal de Turismo do Estado do Rio de Janeiro: Rio das Ostras."
        ),
        FishingSpotMapItem(
            id = "ro-003", name = "Píer Pescador Antônio Miranda", latitude = null, longitude = null,
            environment = "Píer / orla central", fishing = "Possível ponto de pesca; confirmar permissão e sinalização",
            species = "A confirmar por registros locais confiáveis.",
            bait = "Definir após confirmar espécie-alvo.",
            safety = "Atenção a pedestres, embarcações, estrutura, guarda-corpos e sinalização.",
            status = "Incluído como referência para conferência; não há confirmação oficial de regra atual de pesca nesta ficha.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Acesso e permissão de pesca pendentes de confirmação oficial.",
            source = "Referência de localidade; validar com Prefeitura/gestão local."
        ),
        FishingSpotMapItem(
            id = "ro-004", name = "Boca da Barra / Praia do Cemitério", latitude = null, longitude = null,
            environment = "Encontro do rio com o mar / praia", fishing = "Ambiente tradicional de pesca; verificar área permitida",
            species = "Espécies estuarinas e costeiras; ocorrência não garantida.",
            bait = "Depende da espécie e da condição da água; confirmar com pescadores locais.",
            safety = "Atenção à correnteza na foz, embarcações, maré e circulação de banhistas.",
            status = "Referência geográfica e turística. A permissão de pesca deve ser verificada no trecho exato.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Acesso público em áreas da orla; regras específicas pendentes de confirmação.",
            source = "Prefeitura de Rio das Ostras: circuito de pontos turísticos; referências hidrográficas regionais."
        ),
        FishingSpotMapItem(
            id = "ro-005", name = "Praia do Mar do Norte", latitude = null, longitude = null,
            environment = "Praia oceânica / costões", fishing = "Pesca citada em material regional; confirmar áreas e restrições",
            species = "Peixes costeiros; consultar registros recentes.",
            bait = "Escolher conforme espécie-alvo e maré.",
            safety = "Trechos mais naturais e costões exigem atenção a ondas, pedras escorregadias e acesso.",
            status = "Aparece em material regional como local frequentado por pescadores; confirmar regras ambientais atuais.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Acesso e restrições ambientais por trecho precisam ser conferidos.",
            source = "Geoparque Costões e Lagunas; Portal de Turismo do Estado do Rio de Janeiro."
        ),
        FishingSpotMapItem(
            id = "ro-006", name = "Praia da Joana", latitude = null, longitude = null,
            environment = "Praia pequena / costões rochosos", fishing = "Não recomendar até confirmar regras da unidade de conservação",
            species = "Não sugerir espécies enquanto a regra de uso não estiver confirmada.",
            bait = "Não sugerir iscas como recomendação de pesca neste momento.",
            safety = "Costões escorregadios, ondas e maré podem tornar o acesso perigoso.",
            status = "ALERTA: está associada ao Monumento Natural dos Costões Rochosos. Não presumir pesca permitida.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Regras da unidade de conservação e autorização de pesca pendentes de confirmação.",
            source = "Prefeitura de Rio das Ostras: Pontos Turísticos / Monumento Natural dos Costões Rochosos."
        ),
        FishingSpotMapItem(
            id = "ro-007", name = "Lagoa de Iriry", latitude = null, longitude = null,
            environment = "Lagoa / unidade de conservação", fishing = "Não recomendar pesca até confirmação expressa da legislação e do plano de manejo",
            species = "Não sugerir espécies.",
            bait = "Não sugerir iscas.",
            safety = "Respeite áreas protegidas, placas e orientações da gestão ambiental.",
            status = "BLOQUEADO PARA RECOMENDAÇÃO: situação legal da pesca precisa ser confirmada em fonte municipal atual.",
            coordinateStatus = "Sem coordenada validada no aplicativo.",
            accessStatus = "Área de proteção ambiental; consultar regras oficiais antes de qualquer atividade de pesca.",
            source = "Prefeitura de Rio das Ostras: Pontos Turísticos; legislação/plano de manejo a verificar."
        )
    )
}
