package br.com.pescamapa.brasil

import java.time.MonthDay

data class DefesoCatalogItem(
    val id: String,
    val species: String,
    val start: MonthDay,
    val end: MonthDay,
    val area: String,
    val activity: String,
    val legalReference: String,
    val note: String
)

object DefesoCatalog {
    val items = listOf(
        DefesoCatalogItem("camarao", "Camarões (espécies listadas na norma)", MonthDay.of(1, 28), MonthDay.of(4, 30), "Mar territorial e ZEE de RJ, SP, PR, SC e RS", "Captura de camarões; observar exceção específica para camarão-branco", "Portaria SAP/MAPA nº 656/2022", "A FIPERJ informa exceção para camarão-branco capturado com aparelho que não seja arrasto motorizado e que o enquadramento de águas interiores deve ser verificado."),
        DefesoCatalogItem("sardinha", "Sardinha-verdadeira", MonthDay.of(10, 1), MonthDay.of(2, 28), "Entre Cabo de São Tomé (RJ) e Cabo de Santa Marta (SC)", "Pesca industrial/comercial com cerco de traineira", "IN IBAMA nº 15/2009, alterada pela IN MAPA nº 18/2020", "A tabela estadual consultada especifica cerco de traineira. Não tratar como proibição geral da pesca amadora de vara/linha."),
        DefesoCatalogItem("garoupa", "Garoupa-verdadeira", MonthDay.of(11, 1), MonthDay.of(2, 28), "Águas jurisdicionais brasileiras", "Captura da espécie", "Portaria SG/MMA nº 41/2018", "Confirmar a identificação da espécie; nomes populares podem variar."),
        DefesoCatalogItem("cherne", "Cherne-verdadeiro e peixe-batata", MonthDay.of(9, 1), MonthDay.of(10, 31), "Litorais Sudeste e Sul", "Captura das espécies", "Portaria SG/MMA nº 40/2018", "Restrição específica às espécies listadas, não uma proibição geral no local."),
        DefesoCatalogItem("badejos", "Caranha, badejo-amarelo, badejo-quadrado/sirigado e garoupa-de-São-Tomé", MonthDay.of(8, 1), MonthDay.of(9, 30), "Águas jurisdicionais brasileiras", "Captura das espécies", "Portaria SG/MMA nº 59-C/2018", "Confirmar a identificação correta das espécies."),
        DefesoCatalogItem("mexilhao", "Mexilhão", MonthDay.of(9, 1), MonthDay.of(12, 31), "Litoral Sudeste e Sul", "Extração/coleta de mexilhão", "IN IBAMA nº 105/2006", "Esta regra é sobre coleta de mexilhão, não pesca de peixes com vara e anzol."),
        DefesoCatalogItem("uca-machos", "Caranguejo-uçá macho", MonthDay.of(10, 1), MonthDay.of(11, 30), "RJ, ES, SP, PR e SC", "Captura/coleta de machos", "Portaria IBAMA nº 52/2003", "Período específico para machos: 01/out a 30/nov."),
        DefesoCatalogItem("uca-femeas", "Caranguejo-uçá fêmea", MonthDay.of(10, 1), MonthDay.of(12, 31), "RJ, ES, SP, PR e SC", "Captura/coleta de fêmeas", "Portaria IBAMA nº 52/2003", "Fêmeas protegidas de 01/out a 31/dez.")
    )
}
