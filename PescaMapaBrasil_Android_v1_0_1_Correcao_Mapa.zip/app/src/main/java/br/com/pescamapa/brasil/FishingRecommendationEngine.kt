package br.com.pescamapa.brasil

data class FishingConditions(
    val windKmh: Double,
    val waveHeightM: Double,
    val tideRising: Boolean,
    val daylight: Boolean,
    val rain: Boolean
)

data class FishingSpot(
    val id: String,
    val name: String,
    val environment: String,
    val fishingType: String,
    val restricted: Boolean = false,
    val safetyWarning: Boolean = false
)

data class Recommendation(
    val spot: FishingSpot,
    val score: Int,
    val reasons: List<String>
)

object FishingRecommendationEngine {
    fun recommend(
        spots: List<FishingSpot>,
        conditions: FishingConditions,
        preferredEnvironment: String? = null
    ): List<Recommendation> {
        return spots
            .map { spot ->
                if (spot.restricted) {
                    Recommendation(spot, 0, listOf("Pesca restrita ou proibida: não recomendar."))
                } else {
                    var score = 50
                    val reasons = mutableListOf<String>()

                    if (spot.safetyWarning) {
                        score -= 35
                        reasons += "Atenção extra de segurança necessária."
                    } else {
                        score += 10
                        reasons += "Sem alerta de segurança cadastrado."
                    }

                    if (preferredEnvironment != null &&
                        spot.environment.contains(preferredEnvironment, ignoreCase = true)) {
                        score += 20
                        reasons += "Ambiente compatível com sua preferência."
                    }

                    if (conditions.waveHeightM > 1.5 && spot.environment.contains("costão", true)) {
                        score -= 20
                        reasons += "Ondulação elevada para costão."
                    }

                    if (conditions.windKmh > 30) {
                        score -= 20
                        reasons += "Vento forte reduz a segurança e a qualidade da pescaria."
                    } else if (conditions.windKmh <= 15) {
                        score += 10
                        reasons += "Vento moderado favorece a pescaria."
                    }

                    if (conditions.rain) {
                        score -= 5
                        reasons += "Chuva prevista: condição menos confortável."
                    }

                    if (conditions.daylight) {
                        score += 5
                        reasons += "Horário com luz natural."
                    }

                    score = score.coerceIn(0, 100)
                    Recommendation(spot, score, reasons)
                }
            }
            .filter { it.score > 0 }
            .sortedByDescending { it.score }
    }
}
