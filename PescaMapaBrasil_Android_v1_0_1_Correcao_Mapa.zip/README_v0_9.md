# PescaMapa Brasil Android - versão 0.9

## Novidade principal
Módulo inicial **Calendário de Defeso e Restrições**, preparado para cruzar:
- espécie;
- período anual;
- área geográfica;
- atividade de pesca;
- equipamento/modalidade;
- exceções;
- norma e fonte oficial.

## Arquivos novos
- `app/src/main/assets/calendario_defeso_rj_v0_9.json`: registros iniciais para o Estado do Rio de Janeiro, com foco no piloto em Rio das Ostras.
- `app/src/main/java/br/com/pescamapa/brasil/DefesoCalendar.kt`: modelo e núcleo de avaliação de datas, inclusive períodos que atravessam dezembro/janeiro.

## Regras incluídas nesta base inicial
- Camarões: 28/jan a 30/abr para o mar territorial e ZEE dos estados RJ, SP, PR, SC e RS, com exceção descrita pela FIPERJ para camarão-branco capturado com aparelho que não seja arrasto motorizado. A FIPERJ também informa que o defeso dos camarões não se aplica às águas interiores, como baías.
- Sardinha-verdadeira: 1/out a 28/fev, com observação de que a tabela da FIPERJ restringe a incidência ao cerco de traineira.
- Garoupa-verdadeira: 1/nov a 28/fev.
- Cherne-verdadeiro e peixe-batata: 1/set a 31/out.
- Caranha, badejo-amarelo, badejo-quadrado/sirigado e garoupa-de-São-Tomé: 1/ago a 30/set.
- Mexilhão: 1/set a 31/dez, aplicável à coleta da espécie.
- Caranguejo-uçá: machos de 1/out a 30/nov; fêmeas de 1/out a 31/dez.

## Fontes consultadas
1. IBAMA, Defesos marinhos, página oficial atualizada em 21/01/2026:
   https://www.gov.br/ibama/pt-br/assuntos/biodiversidade/biodiversidade-aquatica/periodos-de-defeso/defesos-marinhos
2. FIPERJ, Tabela de defesos para o Estado do Rio de Janeiro, versão 01 atualizada em 01/08/2025:
   https://www.rj.gov.br/fiperj/sites/default/files/arquivos-paginas/TABELA%20DE%20DEFESO_20250801_123614_0000_0.pdf
3. IBAMA, explicação geral sobre período de defeso:
   https://www.gov.br/ibama/pt-br/assuntos/biodiversidade/biodiversidade-aquatica/periodos-de-defeso

## Cautelas indispensáveis
- A tabela estadual da FIPERJ consultada é de 01/08/2025. A página do IBAMA foi atualizada em 21/01/2026. Antes de publicar para usuários, revisar as normas no Diário Oficial e nos órgãos competentes.
- A regra não pode ser aplicada só pelo nome de um ponto. É necessário avaliar a área abrangida, a espécie, a atividade e o equipamento.
- Defeso de coleta de mexilhão ou caranguejo não deve aparecer como proibição genérica de pesca de vara.
- Sardinha-verdadeira não deve gerar bloqueio automático de pesca amadora de vara/linha com base somente no registro de cerco de traineira.
- Tainha ficou fora das regras automáticas porque a tabela estadual exige interpretação da norma por área e arte de pesca.
- Lagoa de Iriry e Praia da Joana continuam no módulo separado de áreas protegidas/acesso. Defeso não substitui regra de unidade de conservação.
- "Fora do período desta regra" nunca deve ser traduzido como "pesca liberada". Outras normas podem se aplicar.
- Quando faltar confirmação, exibir "Verificação necessária", nunca um selo verde de autorização.

## Estado técnico
- Código-fonte e dados JSON incluídos.
- JSON validado e pacote ZIP verificado.
- Não compilado no Android Studio nem testado em aparelho.
- O módulo foi preparado como base de dados e lógica; ainda precisa ser conectado à interface do mapa e às fichas de local.

## Próximas etapas sugeridas
1. Conectar o calendário à ficha de cada ponto.
2. Criar filtro por espécie e modalidade.
3. Adicionar avisos de início próximo do defeso.
4. Criar rotina de revisão de normas oficiais antes de cada temporada.
5. Validar a incidência de cada regra nos pontos costeiros e estuarinos de Rio das Ostras.
