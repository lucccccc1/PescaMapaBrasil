# PescaMapa Brasil Android - versão 0.8

## Objetivo desta versão
Organizar o catálogo inicial de locais de pesca de Rio das Ostras com procedência, estado de validação das coordenadas e cautela sobre regras de acesso.

## Novidades
- Catálogo inicial com 7 locais de Rio das Ostras.
- Ficha de cada local com ambiente, tipo de pesca, espécies/iscas indicativas, segurança, estado de acesso e fonte de referência.
- Coordenadas não verificadas foram removidas dos pontos do catálogo. Nenhum marcador é criado para local sem latitude/longitude validadas.
- A lista de pontos próximos só calcula distâncias quando existirem coordenadas válidas.
- Botão para abrir uma pesquisa textual do local no aplicativo de mapas do aparelho.
- A interface avisa que a pesquisa textual não é uma rota GPS nem prova de coordenada validada.
- Praia da Joana aparece com alerta de unidade de conservação e não é recomendada para pesca até confirmar as regras.
- Lagoa de Iriry fica bloqueada nas recomendações até confirmação da legislação e do plano de manejo vigentes.
- Catálogo estruturado em `app/src/main/assets/catalogo_pontos_rio_das_ostras_v0_8.json`.

## Locais no catálogo
1. Píer do Emissário de Costazul
2. Praia de Costazul
3. Píer Pescador Antônio Miranda
4. Boca da Barra / Praia do Cemitério
5. Praia do Mar do Norte
6. Praia da Joana
7. Lagoa de Iriry

## Regras de qualidade dos dados
- `latitude` e `longitude` permanecem nulas até haver validação suficiente.
- Referência turística ou menção a pesca não equivale a autorização irrestrita.
- Unidades de conservação exigem conferência das regras oficiais específicas.
- O Google Maps recebe o nome do local como pesquisa. O aplicativo não calcula rota, não confirma o destino exato e não transforma uma posição aproximada em coordenada confiável.
- Informações sobre espécies e iscas são indicativas, não promessa de captura.

## Fontes de referência consultadas
- Prefeitura de Rio das Ostras, página Pontos Turísticos: https://www.riodasostras.rj.gov.br/pontos-turisticos/
- Jornal Oficial de Rio das Ostras, edição 1896/2026: https://www.riodasostras.rj.gov.br/wp-content/uploads/2026/01/ed-1896.pdf
- Portal de Turismo do Estado do Rio de Janeiro, Rio das Ostras: https://www.turismo.rj.gov.br/cidades/rio-das-ostras/
- FIPERJ, legislação de aquicultura e pesca: https://www.rj.gov.br/fiperj/legislacao
- Geoparque Costões e Lagunas, Rio das Ostras: https://www.geoparquecostoeselagunas.com/rio-das-ostras/

## Como testar
1. Abra a pasta do projeto no Android Studio.
2. Aguarde a sincronização do Gradle.
3. Execute em aparelho Android com internet.
4. Abra a aba Mapa e teste a lista de locais.
5. Toque em um local, leia a ficha e use "Abrir pesquisa no Google Maps".
6. Autorize a localização e observe que não há distância calculada para locais sem coordenadas validadas.

## Limitações
- Este ZIP contém código-fonte, não APK.
- Não foi compilado nem testado em aparelho nesta etapa.
- O MapView e seu ciclo de vida ainda precisam de compilação e teste em Android Studio/aparelho real.
- O catálogo JSON foi incluído como ativo de dados; a tela desta versão usa uma lista Kotlin correspondente para exibição. A leitura dinâmica do JSON poderá ser feita em uma etapa posterior.
- As regras atuais de pesca e de unidades de conservação devem ser confirmadas junto aos órgãos responsáveis antes de publicar o catálogo ao público.
