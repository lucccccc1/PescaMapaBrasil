# PescaMapa Brasil Android v0.4

## Motor de recomendação inicial

Foi adicionado `FishingRecommendationEngine.kt`.

O motor usa uma lógica simples e explicável:
- bloqueia locais restritos;
- reduz pontuação quando há alerta de segurança;
- considera ambiente escolhido;
- penaliza vento forte;
- penaliza ondulação alta em costões;
- considera chuva e luz natural;
- produz uma pontuação de 0 a 100 e explica os motivos.

### Importante
Esta é a primeira camada do motor. Ainda não usa dados online de maré, vento ou ondas. Esses dados serão conectados depois.

### Estratégia
A recomendação nunca deve ser uma promessa de captura. Ela representa uma avaliação de condições e adequação do ponto.

## Próximo salto
Integrar o motor à interface e depois conectar dados reais de localização e condições marítimas.
