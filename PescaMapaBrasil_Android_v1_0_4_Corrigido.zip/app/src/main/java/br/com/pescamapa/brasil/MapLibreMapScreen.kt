package br.com.pescamapa.brasil

import android.Manifest
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import org.maplibre.android.MapLibre
import org.maplibre.android.annotations.Marker
import org.maplibre.android.annotations.MarkerOptions
import org.maplibre.android.camera.CameraPosition
import org.maplibre.android.geometry.LatLng
import org.maplibre.android.maps.MapLibreMap
import org.maplibre.android.maps.MapView
import java.util.Locale
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

@Composable
fun MapLibreMapScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    var selectedSpot by remember { mutableStateOf<FishingSpotMapItem?>(null) }
    var userLocation by remember { mutableStateOf<Location?>(null) }
    var permissionGranted by remember { mutableStateOf(hasLocationPermission(context)) }
    var locationMessage by remember {
        mutableStateOf("A localização só será acessada se você autorizar.")
    }
    var mapLibreMap by remember { mutableStateOf<MapLibreMap?>(null) }
    var mapViewInstance by remember { mutableStateOf<MapView?>(null) }
    var userMarker by remember { mutableStateOf<Marker?>(null) }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { grants ->
        permissionGranted = hasLocationPermission(context)
        if (permissionGranted) {
            locationMessage = "Permissão concedida. Buscando sua posição…"
            readLastKnownLocation(context) { location ->
                if (location != null) userLocation = location
            }
        } else {
            locationMessage = "Permissão não concedida. O mapa continua disponível sem GPS."
        }
    }

    DisposableEffect(context, permissionGranted) {
        if (!permissionGranted) {
            onDispose { }
        } else {
            val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
            val listener = object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    userLocation = location
                    locationMessage = "Posição atualizada pelo aparelho."
                }
                @Deprecated("Deprecated in Android")
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) = Unit
                override fun onProviderEnabled(provider: String) = Unit
                override fun onProviderDisabled(provider: String) = Unit
            }
            try {
                val providers = manager.getProviders(true)
                providers.forEach { provider ->
                    try {
                        manager.requestLocationUpdates(provider, 10_000L, 10f, listener)
                    } catch (_: SecurityException) {
                        // A permissão pode ter sido revogada enquanto a tela estava aberta.
                    }
                }
            } catch (_: Exception) {
                locationMessage = "Não foi possível iniciar o GPS neste aparelho."
            }
            onDispose {
                try { manager.removeUpdates(listener) } catch (_: Exception) { }
            }
        }
    }

    LaunchedEffect(permissionGranted) {
        if (permissionGranted && userLocation == null) {
            readLastKnownLocation(context) { location ->
                if (location != null) {
                    userLocation = location
                    locationMessage = "Última posição conhecida do aparelho."
                } else {
                    locationMessage = "Aguardando sinal de localização. Vá para uma área aberta."
                }
            }
        }
    }

    LaunchedEffect(userLocation, mapLibreMap) {
        val location = userLocation
        val map = mapLibreMap
        if (location != null && map != null) {
            userMarker?.let { map.removeMarker(it) }
            userMarker = map.addMarker(
                MarkerOptions()
                    .position(LatLng(location.latitude, location.longitude))
                    .title("Sua posição")
                    .snippet("Localização do aparelho")
            ).also { it.tag = "user-location" }
        }
    }

    Column(modifier = modifier.fillMaxSize()) {
        Text(
            "Pontos de pesca • Rio das Ostras",
            style = MaterialTheme.typography.titleLarge,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)
        )

        AndroidView(
            modifier = Modifier.weight(1f).fillMaxWidth(),
            factory = { viewContext ->
                MapLibre.getInstance(viewContext)
                MapView(viewContext).apply {
                    mapViewInstance = this
                    onCreate(null)
                    getMapAsync { map ->
                        mapLibreMap = map
                        map.setStyle("https://demotiles.maplibre.org/style.json") {
                            map.cameraPosition = CameraPosition.Builder()
                                .target(LatLng(-22.526, -41.935))
                                .zoom(12.0)
                                .build()

                            RioDasOstrasPrototypeSpots.all
                                .filter { it.latitude != null && it.longitude != null }
                                .forEach { spot ->
                                    val marker = map.addMarker(
                                        MarkerOptions()
                                            .position(LatLng(spot.latitude!!, spot.longitude!!))
                                            .title(spot.name)
                                            .snippet(spot.environment)
                                    )
                                    marker.tag = spot.id
                                }
                            map.setOnMarkerClickListener { marker: Marker ->
                                if (marker.tag == "user-location") {
                                    selectedSpot = null
                                } else {
                                    selectedSpot = RioDasOstrasPrototypeSpots.all
                                        .firstOrNull { it.id == marker.tag }
                                }
                                true
                            }
                        }
                    }
                }
            },
            update = { }
        )

        DisposableEffect(mapViewInstance, lifecycleOwner) {
            val mapView = mapViewInstance
            if (mapView == null) {
                onDispose { }
            } else {
                var started = false
                var resumed = false
                var destroyed = false

                fun pauseMap() {
                    if (resumed && !destroyed) {
                        mapView.onPause()
                        resumed = false
                    }
                }
                fun stopMap() {
                    pauseMap()
                    if (started && !destroyed) {
                        mapView.onStop()
                        started = false
                    }
                }
                fun destroyMap() {
                    if (!destroyed) {
                        stopMap()
                        mapView.onDestroy()
                        destroyed = true
                    }
                }

                val observer = LifecycleEventObserver { _, event ->
                    when (event) {
                        Lifecycle.Event.ON_START -> {
                            if (!started && !destroyed) {
                                mapView.onStart()
                                started = true
                            }
                        }
                        Lifecycle.Event.ON_RESUME -> {
                            if (!resumed && !destroyed) {
                                if (!started) {
                                    mapView.onStart()
                                    started = true
                                }
                                mapView.onResume()
                                resumed = true
                            }
                        }
                        Lifecycle.Event.ON_PAUSE -> pauseMap()
                        Lifecycle.Event.ON_STOP -> stopMap()
                        Lifecycle.Event.ON_DESTROY -> destroyMap()
                        else -> Unit
                    }
                }
                lifecycleOwner.lifecycle.addObserver(observer)

                // A view pode ser criada depois de ON_START/ON_RESUME. Sincroniza
                // imediatamente com o estado atual, sem esperar outro evento.
                when {
                    lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED) -> {
                        if (!started) {
                            mapView.onStart()
                            started = true
                        }
                        if (!resumed) {
                            mapView.onResume()
                            resumed = true
                        }
                    }
                    lifecycleOwner.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED) -> {
                        if (!started) {
                            mapView.onStart()
                            started = true
                        }
                    }
                }

                onDispose {
                    lifecycleOwner.lifecycle.removeObserver(observer)
                    destroyMap()
                    if (mapViewInstance === mapView) mapViewInstance = null
                }
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Button(
                onClick = {
                    if (hasLocationPermission(context)) {
                        permissionGranted = true
                        readLastKnownLocation(context) { location ->
                            if (location != null) userLocation = location
                        }
                    } else {
                        permissionLauncher.launch(
                            arrayOf(
                                Manifest.permission.ACCESS_COARSE_LOCATION,
                                Manifest.permission.ACCESS_FINE_LOCATION
                            )
                        )
                    }
                },
                modifier = Modifier.weight(1f)
            ) {
                Text(if (permissionGranted) "Atualizar GPS" else "Usar minha localização")
            }
            OutlinedButton(
                onClick = {
                    val loc = userLocation
                    if (loc != null) {
                        mapLibreMap?.animateCamera(
                            org.maplibre.android.camera.CameraUpdateFactory.newLatLngZoom(
                                LatLng(loc.latitude, loc.longitude), 14.0
                            )
                        )
                    }
                },
                enabled = userLocation != null
            ) { Text("Minha posição") }
        }

        Text(
            locationMessage,
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 3.dp)
        )
        Text(
            "Catálogo de Rio das Ostras • ${RioDasOstrasPrototypeSpots.all.size} locais. Sem coordenada validada, sem marcador no mapa.",
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
        )
        LazyColumn(
            modifier = Modifier.height(132.dp).fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(3.dp)
        ) {
            items(RioDasOstrasPrototypeSpots.all) { spot ->
                Column(
                    modifier = Modifier.fillMaxWidth().clickable { selectedSpot = spot }
                        .padding(horizontal = 16.dp, vertical = 5.dp)
                ) {
                    Text(spot.name, style = MaterialTheme.typography.bodyMedium)
                    Text(spot.accessStatus, style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF795500))
                }
            }
        }

        val nearby = remember(userLocation) {
            val location = userLocation
            if (location == null) emptyList()
            else RioDasOstrasPrototypeSpots.all
                .filter { it.latitude != null && it.longitude != null }
                .map { spot -> spot to distanceKm(location.latitude, location.longitude, spot.latitude!!, spot.longitude!!) }
                .sortedBy { it.second }
        }

        if (userLocation != null) {
            Text(
                "Pontos próximos (distância em linha reta)",
                style = MaterialTheme.typography.titleSmall,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp)
            )
            LazyColumn(
                modifier = Modifier.height(112.dp).fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                items(nearby) { (spot, distance) ->
                    Row(
                        modifier = Modifier.fillMaxWidth().clickable { selectedSpot = spot }
                            .padding(horizontal = 16.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(spot.name, style = MaterialTheme.typography.bodySmall)
                        Text(String.format(Locale("pt", "BR"), "%.1f km", distance),
                            style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }

        selectedSpot?.let { spot ->
            Card(
                modifier = Modifier.fillMaxWidth().padding(12.dp),
                shape = RoundedCornerShape(16.dp),
                elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxWidth().padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(spot.name, style = MaterialTheme.typography.titleMedium)
                    Text("Ambiente: ${spot.environment}")
                    Text("Tipo de pesca: ${spot.fishing}")
                    Text("Espécies: ${spot.species}")
                    Text("Iscas: ${spot.bait}")
                    Text("Segurança: ${spot.safety}")
                    Text("Observação: ${spot.status}", color = Color(0xFF8A5A00),
                        style = MaterialTheme.typography.bodySmall)
                    Text("Coordenadas: ${spot.coordinateStatus}", style = MaterialTheme.typography.bodySmall)
                    Text("Acesso/regras: ${spot.accessStatus}", style = MaterialTheme.typography.bodySmall)
                    Text("Fonte: ${spot.source}", style = MaterialTheme.typography.bodySmall)
                    Button(onClick = { openMapSearch(context, spot.name) }) {
                        Text("Abrir pesquisa no Google Maps")
                    }
                    Text("A pesquisa abre pelo nome, não é uma rota nem uma coordenada validada.",
                        style = MaterialTheme.typography.bodySmall)
                    Text("Fechar ficha", color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.clickable { selectedSpot = null })
                }
            }
        } else {
            Text(
                "Toque em um local do catálogo para consultar a ficha. Marcadores e distâncias só serão exibidos após validação das coordenadas.",
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                style = MaterialTheme.typography.bodySmall
            )
        }
    }
}

private fun hasLocationPermission(context: Context): Boolean {
    val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) ==
        PackageManager.PERMISSION_GRANTED
    return fine || coarse
}

private fun readLastKnownLocation(context: Context, onResult: (Location?) -> Unit) {
    if (!hasLocationPermission(context)) {
        onResult(null)
        return
    }
    val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    try {
        val candidates = manager.getProviders(true).mapNotNull { provider ->
            try { manager.getLastKnownLocation(provider) } catch (_: SecurityException) { null }
        }
        onResult(candidates.maxByOrNull { it.time })
    } catch (_: Exception) {
        onResult(null)
    }
}

private fun distanceKm(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val earthRadiusKm = 6371.0
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
        cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
        sin(dLon / 2) * sin(dLon / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return earthRadiusKm * c
}

private fun openMapSearch(context: Context, placeName: String) {
    val query = Uri.encode("$placeName, Rio das Ostras, RJ")
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=$query"))
    context.startActivity(intent)
}
