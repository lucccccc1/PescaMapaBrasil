package br.com.pescamapa.brasil

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.time.LocalDate
import java.time.MonthDay
import java.util.Locale

private fun MonthDay.toPtBr(): String = String.format(Locale("pt", "BR"), "%02d/%02d", dayOfMonth, monthValue)

@Composable
fun DefesoScreen() {
    val today = LocalDate.now()
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text("📅 Calendário de Defeso", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
            Text("Referências iniciais para o Estado do Rio de Janeiro. Consulte sempre a norma completa e confirme área, espécie, atividade e equipamento.", color = Color(0xFF52677A))
        }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF4D6))) {
                Text("Atenção: estar fora do período de uma regra não significa que a pesca esteja liberada. Outras normas, áreas protegidas e restrições locais podem se aplicar.", modifier = Modifier.padding(14.dp), color = Color(0xFF6D4C00))
            }
        }
        items(DefesoCatalog.items) { item ->
            val active = DefesoCalendar.isDateInsidePeriod(today, item.start, item.end)
            Card {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Text(item.species, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                    Text("Período: ${item.start.toPtBr()} a ${item.end.toPtBr()}")
                    Text("Área: ${item.area}")
                    Text("Atividade: ${item.activity}")
                    Text("Norma: ${item.legalReference}")
                    Text(item.note, color = Color(0xFF52677A))
                    AssistChip(onClick = {}, label = { Text(if (active) "Data dentro do período desta regra" else "Data fora do período desta regra") })
                }
            }
        }
        item {
            Text("Fontes oficiais", fontWeight = FontWeight.Bold)
            Text("IBAMA: gov.br/ibama/assuntos/biodiversidade/periodos-de-defeso/defesos-marinhos")
            Text("FIPERJ: rj.gov.br/fiperj/legislacao")
            Text("Revisar as normas antes de cada temporada e antes de publicar atualizações.", color = Color(0xFF52677A))
        }
    }
}

@Composable
fun DefesoSpotSummary(onOpenCalendar: () -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5FC))) {
        Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("📅 Defeso e restrições", fontWeight = FontWeight.Bold)
            Text("Consulte os períodos por espécie, área e atividade. A ficha do ponto não presume que a pesca esteja autorizada.")
            OutlinedButton(onClick = onOpenCalendar, modifier = Modifier.fillMaxWidth()) { Text("Abrir calendário de defeso") }
        }
    }
}
