# PescaMapa Brasil 1.0.4

## Revisão desta versão
- Atualizado `versionCode` para 14 e `versionName` para 1.0.4.
- Corrigida a assinatura da tela de mapa: o callback que não era utilizado foi removido e a navegação agora chama `MapScreen()` diretamente.
- Removido import não utilizado da tela principal.
- Removido import de `DateTimeFormatter` não utilizado na tela de defeso.
- Mantidos os dados e avisos de segurança do catálogo; pontos sem coordenadas verificadas continuam sem marcadores no mapa.
- Mantido o fluxo de compilação do GitHub Actions para gerar o APK de depuração.

## Validação
Os arquivos Kotlin e a estrutura do projeto foram revisados estaticamente, e os arquivos JSON do catálogo foram validados quanto à sintaxe.
A compilação Android completa ainda precisa ser confirmada pelo GitHub Actions, pois este ambiente de revisão não possui Gradle instalado nem o SDK Android configurado.
