# PescaMapa Brasil Android - versão 1.0.3 (correções estruturais)

## Correções desta revisão
- Removida a cópia duplicada do projeto que estava dentro do próprio ZIP.
- Corrigido o conflito de nome entre os modelos `FishingSpot` da tela inicial e do motor de recomendações.
- Padronizada a compilação Java/Kotlin em JVM 17.
- Atualizado `versionCode` para 13 e `versionName` para 1.0.3.
- Tornados editáveis os campos do formulário de registro de pescaria.
- Pesquisa inicial passou a aceitar texto e abrir o mapa como próximo passo.
- Conteúdo da comunidade identificado como demonstrativo, para não apresentar relatos fictícios como reais.
- Incluído workflow do GitHub Actions que instala Gradle 8.9, compila o APK e publica o arquivo como artefato.

## O que já existe no projeto
- Interface Android com Jetpack Compose.
- Tela de mapa baseada em MapLibre.
- Solicitação opcional de permissão de localização e leitura de GPS.
- Catálogo inicial de sete referências de pesca de Rio das Ostras, com avisos de acesso e proteção ambiental.
- Núcleo de cálculo de distância e motor inicial de recomendações.
- Tela e catálogo inicial de períodos de defeso.
- Bases JSON de peixes, pontos, defeso e segurança.

## Limitações que ainda precisam ser resolvidas antes de chamar o app de completo
1. O catálogo de locais ainda é um piloto de Rio das Ostras, não uma cobertura nacional.
2. Os pontos sem coordenadas verificadas aparecem em lista, mas não recebem marcador no mapa.
3. O formulário ainda não salva os registros permanentemente nem os sincroniza.
4. A comunidade ainda é demonstrativa, sem cadastro, autenticação ou publicação real.
5. O catálogo de peixes e as regras de defeso precisam de revisão contínua por região, espécie, modalidade, equipamento e norma vigente.
6. O app ainda não integra marés, previsão meteorológica ou alertas oficiais em tempo real.
7. O APK precisa ser compilado no GitHub Actions e testado em aparelho Android real. Esta revisão estática não substitui esses testes.

## Como gerar o APK no GitHub
1. Envie o conteúdo desta pasta para a raiz do repositório `PescaMapaBrasil`, mantendo a pasta `.github`.
2. Abra a aba **Actions**.
3. Execute **Gerar APK Android** (ou aguarde a compilação automática após o push).
4. Abra a execução concluída e baixe o artefato **PescaMapaBrasil-APK**.
5. Teste o APK no celular antes de distribuir.

## Aviso sobre pesca e segurança
As informações são orientativas. A ausência de alerta no aplicativo não significa que a pesca esteja liberada. Confirme as normas oficiais, placas, condições do mar, vento, ondas, correntes e regras de áreas protegidas antes de pescar. Coordenadas aproximadas não devem ser usadas para navegação.

## Fontes de referência do módulo de defeso
- IBAMA: https://www.gov.br/ibama/pt-br/assuntos/biodiversidade/biodiversidade-aquatica/periodos-de-defeso/defesos-marinhos
- FIPERJ: https://www.rj.gov.br/fiperj/legislacao
